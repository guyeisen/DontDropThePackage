import os
import sys
import json
import random


sys.path.append('./src')

from PyQt5 import QtWidgets, QtCore, QtGui

import discopygal
from discopygal.solvers import *
from discopygal.geometry_utils.conversions import float_to_FT

from grid import Grid
from object_drawer import *
from object_selector import *
from preferences_dialog import PreferencesDialog

from scene_designer_gui import Ui_MainWindow, About_Dialog

WINDOW_TITLE = "DiscoPygal Scene Designer"
DEFAULT_ZOOM = 30

class SceneDesignerGUI(Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.set_program_name(WINDOW_TITLE)

        # Fix initial zoom
        self.zoom = DEFAULT_ZOOM
        self.redraw()

        # The DiscoPygal scene
        self.discopygal_scene = Scene()
        self.scene_drawer = SceneDrawer(self, self.discopygal_scene)
        self.scene_metadata_set_version()

        # Setup object selection
        self.object_selector = ObjectSelector(self)
        self.scene.left_click_signal.connect(self.object_selector.left_click_handle)
        self.mainWindow.signal_delete.connect(self.delete_selected_object)
        self.actiondelete.triggered.connect(self.delete_selected_object)

        # Setup object drawer
        self.object_drawer = ObjectDrawer(self)
        self.scene.right_click_signal.connect(self.object_drawer.right_click_handle)
        self.actionpolyObst.triggered.connect(lambda: self.object_drawer.set_object_type_drawing(OBJDRW_OBJ_TYPE_OBST_POLY))
        self.actiondiscObst.triggered.connect(lambda: self.object_drawer.set_object_type_drawing(OBJDRW_OBJ_TYPE_OBST_DISC))
        self.actionpolyRobot.triggered.connect(lambda: self.object_drawer.set_object_type_drawing(OBJDRW_OBJ_TYPE_ROBOT_POLY))
        self.actiondiscRobot.triggered.connect(lambda: self.object_drawer.set_object_type_drawing(OBJDRW_OBJ_TYPE_ROBOT_DISC))
        self.actionrodRobot.triggered.connect(lambda: self.object_drawer.set_object_type_drawing(OBJDRW_OBJ_TYPE_ROBOT_ROD))
        self.object_drawer.set_object_type_drawing(OBJDRW_OBJ_TYPE_OBST_POLY) # Set a default drawing mode

        # Setup grid
        self.grid = Grid(self)
        self.toggle_grid()
        self.actiongrid.triggered.connect(self.toggle_grid)

        # Connect actions and signals
        self.actionPreferences.triggered.connect(self.preferences_dialog)
        self.actionAbout.triggered.connect(self.about_dialog)
        self.actionclearScene.triggered.connect(self.clear_scene)
        self.actionreposition.triggered.connect(self.randomize_colors)
        self.radiusEdit.textChanged.connect(lambda text: self.object_property_updated(text, "radius"))
        self.lengthEdit.textChanged.connect(lambda text: self.object_property_updated(text, "length"))
        self.startAngleEdit.textChanged.connect(lambda text: self.object_property_updated(text, "startAngle"))
        self.endAngleEdit.textChanged.connect(lambda text: self.object_property_updated(text, "endAngle"))
        self.colorEdit.textChanged.connect(lambda text: self.object_property_updated(text, "color"))
        self.nameEdit.textChanged.connect(lambda text: self.object_property_updated(text, "name"))
        self.valueEdit.textChanged.connect(lambda text: self.object_property_updated(text, "value"))
        self.detailsEdit.textChanged.connect(lambda: self.object_property_updated("", "details"))
        self.solversEdit.textChanged.connect(self.scene_metadata_set_solvers)
        self.sceneDetailsEdit.textChanged.connect(self.scene_metadata_set_details)
        self.actionQuit.triggered.connect(lambda: sys.exit(0))

        # Enable scene metadata editing
        self.solversEdit.setEnabled(True)
        self.sceneDetailsEdit.setEnabled(True)

        # Scene save/load
        self.path = ''
        self.changes = False
        self.update_window_title()
        self.actionsave.triggered.connect(self.save_scene)
        self.actionSave.triggered.connect(self.save_scene)
        self.actionSave_As.triggered.connect(lambda: self.save_scene(save_as=True))
        self.actionopen.triggered.connect(self.load_scene)
        self.actionOpen.triggered.connect(self.load_scene)
        self.actionNew.triggered.connect(self.new_scene)
        self.actionNew_2.triggered.connect(self.new_scene)


    def random_hsv(self):
        """
        Return a random HSV color
        """
        h = random.randint(0, 360)
        s = 200
        v = 230
        return 'HSV %d,%d,%d' % (h,s,v)

    def randomize_colors(self):
        """
        Randomize the color of a selected robot.
        If none is selected - randomize all the colors
        """
        if self.object_selector.selected is not None and isinstance(self.object_selector.selected, Robot):
            self.object_selector.selected.data['color'] = self.random_hsv()
        else:
            for robot in self.discopygal_scene.robots:
                robot.data['color'] = self.random_hsv()
        self.object_drawer.refresh_scene()
        
    def scene_metadata_set_version(self):
        version = discopygal.__version__
        self.versionEdit.setText(version)
        self.discopygal_scene.metadata['version'] = version
    
    def scene_metadata_set_solvers(self, text):
        self.discopygal_scene.metadata['solvers'] = text
        self.scene_changed()
    
    def scene_metadata_set_details(self):
        self.discopygal_scene.metadata['details'] = self.sceneDetailsEdit.toPlainText()
        self.scene_changed()

    def scene_metadata_load(self):
        """
        Load metadata variables to GUI when loading a scene
        """
        if 'solvers' not in self.discopygal_scene.metadata:
            self.discopygal_scene.metadata['solvers'] = ""
        self.solversEdit.setText(self.discopygal_scene.metadata['solvers'])
        if 'details' not in self.discopygal_scene.metadata:
            self.discopygal_scene.metadata['details'] = ""
        self.sceneDetailsEdit.setPlainText(self.discopygal_scene.metadata['details'])

        
    def save_scene(self, save_as=False):
        """
        Save the current scene. 
        If the given path is set - then save without prompt, otherwise prompt a file save dialog.
        """
        if self.path == '' or save_as:
            name, _ = QtWidgets.QFileDialog.getSaveFileName(self.mainWindow, 'Save File')
            if name == '':
                return
            self.path = name
        
        d = self.discopygal_scene.to_dict()
        with open(self.path, 'w') as fp:
            json.dump(d, fp)
        self.changes = False
        self.update_window_title()
    
    def ask_unsaved_changes(self):
        """
        Check if user has unsaved changes and ask if to save, dicard changes or abort.
        Return True if user prompted abort
        """
        if self.changes == True:
            msgbox = QtWidgets.QMessageBox(
                QtWidgets.QMessageBox.Icon.Warning, 
                "Unsaved changes", "Would you like to save the changes? (Any unsaved changes will be discarded)",
                QtWidgets.QMessageBox.StandardButton.Save | QtWidgets.QMessageBox.StandardButton.Discard | QtWidgets.QMessageBox.StandardButton.Cancel, 
                self.mainWindow)
            ret = msgbox.exec()
            if ret == QtWidgets.QMessageBox.StandardButton.Save:
                self.save_scene()
                return False
            elif ret == QtWidgets.QMessageBox.StandardButton.Discard:
                return False
            elif ret == QtWidgets.QMessageBox.StandardButton.Cancel:
                return True
        return False
    
    def load_scene(self):
        """
        Load a scene.
        """
        # Ask for save changes
        should_abort = self.ask_unsaved_changes()
        if should_abort:
            return

        name, _ = QtWidgets.QFileDialog.getOpenFileName(self.mainWindow, 'Load File')
        if name == '':
            return

        with open(name, 'r') as fp:
            d = json.load(fp)
        self.discopygal_scene = Scene.from_dict(d)
        self.scene_drawer.clear_scene()
        self.scene_drawer.scene = self.discopygal_scene
        self.scene_drawer.draw_scene()
        self.object_selector.selected = None
        self.update_object_properties(select=False)

        # Update the version of the scene and other metadata
        version_mismatch = False
        if 'version' not in self.discopygal_scene.metadata or self.discopygal_scene.metadata['version'] != discopygal.__version__:
            version_mismatch = True
        self.scene_metadata_set_version()
        self.scene_metadata_load()

        self.path = name
        self.changes = version_mismatch
        self.update_window_title()
    

    def new_scene(self):
        """
        Discard current scene and create a new one.
        """
        # Ask for save changes
        should_abort = self.ask_unsaved_changes()
        if should_abort:
            return
            
        self.object_selector.selected = None
        self.update_object_properties(select=False)
        self.clear_scene()
        self.scene_metadata_set_version()


        self.path = ''
        self.changes = False
        self.update_window_title()


    def scene_changed(self):
        """
        This function is called everytime there was made (even minor) change to the scene
        """
        self.changes = True
        self.update_window_title()


    def update_window_title(self):
        """
        Update the window title (to include filename + changes)
        """
        # Get the file basename
        if self.path == '':
            basename = 'Untitled'
        else:
            basename = os.path.basename(self.path)
        
        title = WINDOW_TITLE + ' - ' + basename
        if self.changes:
            title += ' *'
        self.set_program_name(title)

        

    def delete_selected_object(self):
        """
        Delete the selected object (if exists)
        """
        selected = self.object_selector.selected
        if selected is None:
            return
        
        # Reset the selected object
        self.object_selector.selected = None

        # Clear the scene
        self.scene_drawer.clear_scene()

        # Remove the entity from the scene
        if isinstance(selected, Obstacle):
            self.discopygal_scene.remove_obstacle(selected)
        elif isinstance(selected, Robot):
            self.discopygal_scene.remove_robot(selected)
        
        # Refresh the scene
        self.scene_drawer.draw_scene()
        self.scene_changed()

    
    def object_property_updated(self, text, property):
        """
        Called when user updates a property of an object
        """
        obj = self.object_selector.selected
        if obj is None:
            return

        if property == "radius":
            if text == '':
                text = str(OBJDRW_DEFAULT_RADIUS)
            obj.radius = float_to_FT(float(text))
        elif property == "length":
            if text == '':
                text = str(OBJDRW_DEFAULT_LENGTH)
            obj.length = float_to_FT(float(text))
        elif property == "startAngle":
            if text == '':
                text = str(OBJDRW_DEFAULT_START_ANGLE)
            obj.start = obj.start[0], float_to_FT(float(text))
        elif property == "endAngle":
            if text == '':
                text = str(OBJDRW_DEFAULT_END_ANGLE)
            obj.end = obj.end[0], float_to_FT(float(text))
        elif property == "details":
            obj.data['details'] = self.detailsEdit.toPlainText()
        else:
            obj.data[property] = text

        self.object_drawer.refresh_scene()
        self.scene_changed()


    def update_object_properties(self, select):
        """
        Update the object properties panel.
        Clear object metadata when deselcting.

        If select is true, we also show the object's properties
        """
        if self.object_selector.selected is None:
            select = False

        if not select:
            self.object_properties_enabled_fields(self.object_drawer.obj_type, select)
        else:
            obj_type = None
            if type(self.object_selector.selected) is ObstaclePolygon:
                obj_type = OBJDRW_OBJ_TYPE_OBST_POLY
            elif type(self.object_selector.selected) is ObstacleDisc:
                obj_type = OBJDRW_OBJ_TYPE_OBST_DISC
            elif type(self.object_selector.selected) is RobotPolygon:
                obj_type = OBJDRW_OBJ_TYPE_ROBOT_POLY
            elif type(self.object_selector.selected) is RobotDisc:
                obj_type = OBJDRW_OBJ_TYPE_ROBOT_DISC
            elif type(self.object_selector.selected) is RobotRod:
                obj_type = OBJDRW_OBJ_TYPE_ROBOT_ROD
            assert(obj_type is not None)
            self.object_properties_enabled_fields(obj_type, select)
        
        # Update object metadata fields
        if select:
            self.colorEdit.setText(self.object_selector.selected.data['color'])
            self.nameEdit.setText(self.object_selector.selected.data['name'])
            self.valueEdit.setText(self.object_selector.selected.data['value'])
            self.detailsEdit.setPlainText(self.object_selector.selected.data['details'])
            # Also update geometric properties, if relevant
            if obj_type in [OBJDRW_OBJ_TYPE_OBST_DISC, OBJDRW_OBJ_TYPE_ROBOT_DISC]:
                self.radiusEdit.setText(str(self.object_selector.selected.radius))
            elif obj_type in [OBJDRW_OBJ_TYPE_ROBOT_ROD]:
                self.lengthEdit.setText(str(self.object_selector.selected.length))
                self.startAngleEdit.setText(str(self.object_selector.selected.start[1]))
                self.endAngleEdit.setText(str(self.object_selector.selected.end[1]))
        else:
            self.colorEdit.setText("")
            self.nameEdit.setText("")
            self.valueEdit.setText("")
            self.detailsEdit.setPlainText("")

    
    def object_properties_enabled_fields(self, obj_type, select):
        """
        Given the currect object type we draw or edit, set which fields are availabe
        """
        self.radiusEdit.setEnabled(obj_type in [OBJDRW_OBJ_TYPE_OBST_DISC, OBJDRW_OBJ_TYPE_ROBOT_DISC])
        self.lengthEdit.setEnabled(obj_type in [OBJDRW_OBJ_TYPE_ROBOT_ROD])
        self.startAngleEdit.setEnabled(obj_type in [OBJDRW_OBJ_TYPE_ROBOT_ROD])
        self.endAngleEdit.setEnabled(obj_type in [OBJDRW_OBJ_TYPE_ROBOT_ROD])
        self.colorEdit.setEnabled(select)
        self.nameEdit.setEnabled(select)
        self.valueEdit.setEnabled(select)
        self.detailsEdit.setEnabled(select)

        if self.radiusEdit.text().strip() == "":
            self.radiusEdit.setText(str(OBJDRW_DEFAULT_RADIUS))
        if self.lengthEdit.text().strip() == "":
            self.lengthEdit.setText(str(OBJDRW_DEFAULT_LENGTH))
        if self.startAngleEdit.text().strip() == "":
            self.startAngleEdit.setText(str(OBJDRW_DEFAULT_START_ANGLE))
        if self.endAngleEdit.text().strip() == "":
            self.endAngleEdit.setText(str(OBJDRW_DEFAULT_END_ANGLE))

    def get_object_properties(self):
        """
        Return a dict of the current object's properties (misc data)
        """
        return {
            "color": self.colorEdit.text().strip(),
            "name": self.nameEdit.text().strip(),
            "value": self.valueEdit.text().strip(),
            "details": self.detailsEdit.toPlainText().strip()
        }

    def get_property(self, property):
        if property == "radius":
            return self.radiusEdit.text().strip()
        if property == "length":
            return self.lengthEdit.text().strip()
        if property == "start_angle":
            return self.startAngleEdit.text().strip()
        if property == "end_angle":
            return self.endAngleEdit.text().strip()
        return ""
    
    def preferences_dialog(self):
        """
        Open the preferences dialog
        """
        dialog = QtWidgets.QDialog()
        dialog.ui = PreferencesDialog(self, dialog)
        dialog.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        dialog.setWindowTitle('Preferences')
        dialog.exec_()
    
    def about_dialog(self):
        """
        Open the about dialog
        """
        dialog = QtWidgets.QDialog()
        dialog.ui = About_Dialog()
        dialog.ui.setupUi(dialog)
        dialog.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        dialog.setWindowTitle('About')
        dialog.exec_()
    
    def toggle_grid(self):
        """
        Draw the grid, using the given grid options
        """
        if self.grid.enabled:
            self.grid.clear_grid()
            self.grid.enabled = False
        else:
            self.grid.draw_grid()
            self.grid.enabled = True
    
    def clear_scene(self):
        """
        Clear the scene
        """
        self.scene_drawer.clear_scene()
        self.object_drawer.clear_drawing()
        self.discopygal_scene.clear()
        self.scene_changed()


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    gui = SceneDesignerGUI()
    gui.mainWindow.show()
    sys.exit(app.exec_())