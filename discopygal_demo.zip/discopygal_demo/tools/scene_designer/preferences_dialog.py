from scene_designer_gui import Ui_Dialog

class PreferencesDialog(Ui_Dialog):
    def __init__(self, gui, dialog):
        super().__init__()
        self.gui = gui # pointer to parent gui
        self.setupUi(dialog)

        self.get_grid_settings()

        self.updateButton.clicked.connect(self.update_settings)

    def update_settings(self):
        """
        Update all the settings in the dialog
        """
        self.update_grid_settings()

    def get_grid_settings(self):
        """
        Fetch the currect grid settings from the gui
        """
        size = self.gui.grid.size
        resolution = self.gui.grid.resolution
        self.gridLengthEdit.setText(str(size))
        self.gridResolutionEdit.setText(str(resolution))

    def update_grid_settings(self):
        size = int(self.gridLengthEdit.text())
        resolution = float(self.gridResolutionEdit.text())
        self.gui.grid.size = size
        self.gui.grid.resolution = resolution
        
        # Redraw grid if necessary
        if self.gui.grid.enabled:
            self.gui.grid.draw_grid()
