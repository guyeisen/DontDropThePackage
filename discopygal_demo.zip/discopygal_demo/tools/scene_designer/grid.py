from PyQt5 import QtCore

GRID_COLOR = QtCore.Qt.lightGray
GRID_DEFAULT_SIZE = 200
GRID_DEFAULT_RESOLUTION = 1.0

class Grid(object):
    def __init__(self, gui):
        self.grid_segments = []
        self.gui = gui # pass pointer to parent gui

        # Properties
        self.size = GRID_DEFAULT_SIZE
        self.resolution = GRID_DEFAULT_RESOLUTION
        self.enabled = False
    
    def clear_grid(self):
        """
        Clear the grid lines from the scene
        """
        for segment in self.grid_segments:
            self.gui.scene.removeItem(segment.line)
        self.grid_segments.clear()
    
    def draw_grid(self):
        """
        Draw grid lines in the scene
        """
        self.clear_grid()

        # draw grid lines
        length = self.size * self.resolution
        for i in range(-self.size, self.size):
            if i == 0:
                color = QtCore.Qt.black
            else:
                color = GRID_COLOR
            i = i * self.resolution
            self.grid_segments.append(self.gui.add_segment(-length, i, length, i, line_color=color))
            self.grid_segments.append(self.gui.add_segment(i, -length, i, length, line_color=color))
        
        # make sure lines are in the back
        for segment in self.grid_segments:
            segment.line.setZValue(-1)