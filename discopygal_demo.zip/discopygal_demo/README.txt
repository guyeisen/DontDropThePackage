This folder has the minimal setup needed to get up and running with DiscoPygal 2 :)
The documentation for the library, as well as a thourough installation guide can be found in: https://www.cs.tau.ac.il/~cgl/discopygal/docs/index.html

Prerequisits:
------------

	* Python 3.9 or newer
	* pipenv (via pip install pipenv)

To install the environemnt:
--------------------------

	1. In the current folder, run: 
		pipenv shell
	2. Install dependecies (temporary measure, will be fixed in next DSPGL versions!):
		pipenv install
	3. Install CGALPY:
		pip install CGALPY-1.0-py3-none-any.whl
	4. Install DiscoPygal:
		pip install discopygal_taucgl-1.0.1-py3-none-any.whl

The examples provided:
----------------------

	* Basic GUI example (soon there will also be a more elaborate tutorial) - 
	  An example for a simple Qt GUI application using the DiscoPygal interface

		python examples\basic_gui_example.py

	* Simple Motion Planning -
	  The example provided in the quickstart guide. Explain how to create a simple scene with two robots
	  and obstacles (the scene is created manually - without a designer).
	  Then dRRT is applied to plan motion for both robots (and we print the paths).

		python examples\simple_motion_planning.py

There are also two tools available:
----------------------------------

	* The scene designer - allows for desigining scenes
	
		python tools\scene_designer\scene_designer_main.py
	
	* The solver viewer - similar to the "mrmp.py" from past version of DiscoPygal
  	  Allows for loading any motion planning solver and any scene, and plan motion for the given scene.
  	  Also supports debug visualizations like graphs and arrangements.

		python tools\solver_viewer\solver_viewer_main.py

	Video tutorial for using the tools: https://youtu.be/uBjQgzynvaE


